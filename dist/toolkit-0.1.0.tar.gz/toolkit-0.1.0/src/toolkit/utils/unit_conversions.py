import numpy as np

ARCSEC_2_TO_STERADIAN = (np.pi / (180.0 * 3600.0))**2